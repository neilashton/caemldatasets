#!/usr/bin/env python3
"""Reproduce the WindsorML v2 benchmark splits from the pinned v1 manifest."""

import argparse
import hashlib
import json
from pathlib import Path


V1_SHA256 = "717957442d7deb0e3d5ad9e0078fa8b419c63732aca60937b69601d07abdb836"
V1_REVISION = "8a6ca32ae22c94f54df2186d1b0ccf9662a294c2"
DUPLICATE_PAIRS = ((30, 31), (133, 134), (230, 231), (241, 242), (270, 271), (304, 305))
PARTITIONS = ("train", "val", "test")
EXPECTED_COUNTS = {
    "full": (276, 33, 35),
    "medium": (90, 33, 35),
    "scarce": (45, 33, 35),
    "super_scarce": (7, 33, 35),
    "geometry": (239, 34, 71),
    "high_drag": (239, 35, 70),
    "low_drag": (242, 35, 67),
    "image_wake": (239, 34, 71),
}


def write_json(path, data):
    payload = (json.dumps(data, indent=2) + "\n").encode()
    path.write_bytes(payload)
    return hashlib.sha256(payload).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("legacy_manifest", type=Path)
    parser.add_argument("--out-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    legacy = args.legacy_manifest.read_bytes()
    if hashlib.sha256(legacy).hexdigest() != V1_SHA256:
        raise SystemExit("The input must be the original WindsorML split manifest.")

    excluded_duplicates = [f"run_{drop}" for _, drop in DUPLICATE_PAIRS]
    unavailable = [f"run_{case}" for case in range(350, 355)]
    eligible = [f"run_{case}" for case in range(350) if f"run_{case}" not in excluded_duplicates]
    allowed = set(eligible)
    v1 = json.loads(legacy)
    expected_keys = {f"{family}_{part}" for family in EXPECTED_COUNTS for part in PARTITIONS}
    if set(v1) != expected_keys:
        raise SystemExit("Unexpected split keys in the original manifest.")
    v2 = {key: [case for case in cases if case in allowed] for key, cases in v1.items()}

    for family, counts in EXPECTED_COUNTS.items():
        partitions = [v2[f"{family}_{part}"] for part in PARTITIONS]
        membership = {case for partition in partitions for case in partition}
        if tuple(map(len, partitions)) != counts or len(membership) != sum(counts):
            raise SystemExit(f"Incorrect split size or overlapping partitions in {family}.")
        if family not in ("medium", "scarce", "super_scarce") and membership != allowed:
            raise SystemExit(f"Incomplete case coverage in {family}.")
    for child, parent in (("super_scarce", "scarce"), ("scarce", "medium"), ("medium", "full")):
        if not set(v2[f"{child}_train"]) < set(v2[f"{parent}_train"]):
            raise SystemExit(f"{child} training cases must be nested inside {parent}.")
        for part in ("val", "test"):
            if v2[f"{child}_{part}"] != v2[f"{parent}_{part}"]:
                raise SystemExit(f"{child} and {parent} no longer share {part} cases.")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    digest = write_json(args.out_dir / "manifest.json", v2)
    write_json(args.out_dir / "release.json", {
        "version": 2,
        "manifest_sha256": digest,
        "source": {
            "revision": V1_REVISION,
            "path": "splits/manifest.json",
            "sha256": V1_SHA256,
        },
        "aggregate_design_count": 355,
        "downloadable_run_count": 350,
        "eligible_run_count": len(eligible),
        "eligible_run_ids": eligible,
        "duplicate_geometry_pairs": [
            {"retained": f"run_{keep}", "excluded": f"run_{drop}"} for keep, drop in DUPLICATE_PAIRS
        ],
        "unavailable_run_ids": unavailable,
        "split_counts": {family: dict(zip(PARTITIONS, counts)) for family, counts in EXPECTED_COUNTS.items()},
    })
    print(digest)


if __name__ == "__main__":
    main()
