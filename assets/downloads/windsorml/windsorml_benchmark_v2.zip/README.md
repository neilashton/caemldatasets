# WindsorML benchmark splits v2

Use [manifest.json](manifest.json) to select training, validation and test cases for the eight WindsorML benchmark splits. The [release record](release.json) lists eligible run IDs, the checksums of both split manifests and the source dataset revision.

The aggregate tables cover 355 design IDs, and 350 have downloadable per-run data. Version 2 uses 344 eligible runs. It excludes six runs whose geometry is identical to a lower-numbered run despite a different design-parameter record. Geometry identity was verified in the binary STL triangle records and STEP DATA sections. In each pair, the geometry is consistent with the lower-numbered run's clearance. CFD outputs can differ between paired runs.

| Retained | Excluded |
| --- | --- |
| run_30 | run_31 |
| run_133 | run_134 |
| run_230 | run_231 |
| run_241 | run_242 |
| run_270 | run_271 |
| run_304 | run_305 |

Runs 350–354 lack per-run downloads and are also excluded. The remaining runs keep their original v1 assignments. The raw data and the [v1 split methodology](../README.md) remain available for reproducibility. In v1, matched geometries can occur across training, validation and test partitions.

Use the v2 splits for new work. If an excluded run was used to train, tune or evaluate a model, repeat the affected steps with the v2 case lists and report the split version with your results.

To reproduce the v2 manifest and release record, download the v1 manifest at the revision given in the release record and run:

```bash
python build_manifest.py path/to/v1/manifest.json --out-dir ./reproduced
```

Thanks to Daniel Leibovici for reporting the duplicate geometries.
